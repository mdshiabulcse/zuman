<!DOCTYPE html>
<html class="no-js" lang="en">


<!-- Mirrored from sojonever.com/html/zuman/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Mar 2019 13:39:14 GMT -->
<head>
    <meta charset="utf-8">
    <meta name="description" content="Zuman - Creative Personal Portfolio">
    <meta name="keywords" content="Portfolio, Personal, Creatiev, Zuman, Html Template, Portfolio Template">
    <meta name="author" content="ixTheme">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Title -->
    <title>Zuman - Creative Personal Portfolio</title>
    <!-- Favicon -->
    <link href="img/favicon.png" type="image/png" rel="icon">

    <!-- All CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/ionicons.css" rel="stylesheet" type="text/css">
    <link href="css/mobiriseicons.css" rel="stylesheet" type="text/css">
    <link href="css/owl.carousel.min.css" rel="stylesheet" type="text/css">
    <link href="css/splitting.css" rel="stylesheet" type="text/css">
    <link href="css/magnific-popup.css" rel="stylesheet" type="text/css">
    <link href="css/main.css" rel="stylesheet" type="text/css">
    <link href="css/responsive.css" rel="stylesheet" type="text/css">
</head>

<body id="top" data-spy="scroll" data-target="#menu_items">
    <!--[if lte IE 9]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
    <![endif]-->

    <!--  start page loader  -->
    <div id="preloader">
        <div class="scroll-static"></div>
    </div>
    <!--  end page loader  -->
    