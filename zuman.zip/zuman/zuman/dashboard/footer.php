

	<script type="dashboardasset/text/javascript" src="js/jquery.1.11.1.js"></script> 
<script type="dashboardasset/text/javascript" src="js/bootstrap.js"></script> 
<script type="dashboardasset/text/javascript" src="js/SmoothScroll.js"></script> 
<script type="dashboardasset/text/javascript" src="js/nivo-lightbox.js"></script> 
<script type="dashboardasset/text/javascript" src="js/jqBootstrapValidation.js"></script> 
<script type="dashboardasset/text/javascript" src="js/main.js"></script>
</body>
</html>
