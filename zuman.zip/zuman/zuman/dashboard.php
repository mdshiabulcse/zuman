
<?php  
require_once "dashboard/header.php";
 ?>

<div class="col-lg-12">
	<h1>Welcome To Dashboard</h1>
</div>

 <?php 
require_once "dashboard/footer.php";
 ?>