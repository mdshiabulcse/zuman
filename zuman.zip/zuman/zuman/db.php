<?php

$hostname="localhost";
$username="root";
$password="";
$dbname="zuman";

$db_connection=mysqli_connect($hostname,$username,$password,$dbname);



?>