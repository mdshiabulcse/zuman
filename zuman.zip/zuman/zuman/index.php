<?php

require 'include/a_header.php';
require 'include/b_navber.php';
require 'include/c_about.php';
require 'include/d_service.php';
require 'include/e_work.php';
require 'include/f_counter.php';
require 'include/g_testimonial.php';
require 'include/h_contact.php';
require 'include/i_footer.php';










?>           